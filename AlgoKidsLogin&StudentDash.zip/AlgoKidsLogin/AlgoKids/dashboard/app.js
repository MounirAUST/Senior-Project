const sideMenu = document.querySelector("aside");
const profileBtn = document.querySelector("#profile-btn");
const themeToggler = document.querySelector(".theme-toggler");
const nextDay = document.getElementById('nextDay');
const prevDay = document.getElementById('prevDay');

if (profileBtn) {
    profileBtn.onclick = function() {
        sideMenu.classList.toggle('active');
    }
}

window.onscroll = () => {
    sideMenu.classList.remove('active');
    if(window.scrollY > 0){
        document.querySelector('header').classList.add('active');
    } else {
        document.querySelector('header').classList.remove('active');
    }
}

if (themeToggler) {
    themeToggler.onclick = function() {
        document.body.classList.toggle('dark-theme');
        themeToggler.querySelector('span:nth-child(1)').classList.toggle('active');
        themeToggler.querySelector('span:nth-child(2)').classList.toggle('active');
    }
}

const Sunday = [
    { time: 'Sunday', roomNumber: 'None', subject: 'No classes', type: '' }
];
const Monday = [
    { time: '09:00 AM', roomNumber: 'Online', subject: 'Sorting Algorithms', type: 'Lesson' }
];
const Tuesday = [
    { time: '10:00 AM', roomNumber: 'Online', subject: 'Recursion', type: 'Lesson' }
];
const Wednesday = [
    { time: '11:00 AM', roomNumber: 'Online', subject: 'Graph Algorithms', type: 'Lesson' }
];
const Thursday = [
    { time: '12:00 PM', roomNumber: 'Online', subject: 'Dynamic Programming', type: 'Lesson' }
];
const Friday = [
    { time: '01:00 PM', roomNumber: 'Online', subject: 'Data Structures', type: 'Lesson' }
];
const Saturday = [
    { time: '02:00 PM', roomNumber: 'Online', subject: 'Algorithm Challenges', type: 'Practice' }
];

let setData = (day) => {
    document.querySelector('table tbody').innerHTML = ''; // Clear previous table data
    let daylist = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    document.querySelector('.timetable div h2').innerHTML = daylist[day];
    
    let dayData;
    switch(day){
        case(0): dayData = Sunday; break;
        case(1): dayData = Monday; break;
        case(2): dayData = Tuesday; break;
        case(3): dayData = Wednesday; break;
        case(4): dayData = Thursday; break;
        case(5): dayData = Friday; break;
        case(6): dayData = Saturday; break;
    }

    dayData.forEach(sub => {
        const tr = document.createElement('tr');
        const trContent = `
            <td>${sub.time}</td>
            <td>${sub.roomNumber}</td>
            <td>${sub.subject}</td>
            <td>${sub.type}</td>
        `;
        tr.innerHTML = trContent;
        document.querySelector('table tbody').appendChild(tr);
    });
}

let now = new Date();
let today = now.getDay();
let day = today;

function logout() {
    localStorage.removeItem("isLoggedIn"); // Clear session if needed
    window.location.href = "../Login/index.html"; // Redirect to login page
}


document.querySelector(".navbar a[href='#']").addEventListener("click", logout);

function timeTableAll(){
    document.getElementById('timetable').classList.toggle('active');
    setData(today);
    document.querySelector('.timetable div h2').innerHTML = "Today's Learning Plan";
}

nextDay.onclick = function() {
    day = (day + 1) % 7;
    setData(day);
}

prevDay.onclick = function() {
    day = (day - 1 + 7) % 7;
    setData(day);
}

setData(day);
document.querySelector('.timetable div h2').innerHTML = "Today's Learning Plan";
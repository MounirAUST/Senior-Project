const Sunday = [
    {   
        time: 'Sunday',
        activity: 'Rest Day',
        topic: 'No Learning Today',
        status: ''
    }
]

const Monday = [
    {   
        time: '09-10 AM',
        activity: 'Video Lesson',
        topic: 'Introduction to Algorithms',
        status: 'Completed'
    },
    {   
        time: '10-11 AM',
        activity: 'Interactive Quiz',
        topic: 'Sorting Algorithms',
        status: 'In Progress'
    },
    {   
        time: '12-01 PM',
        activity: 'Coding Challenge',
        topic: 'Binary Search',
        status: 'Not Started'
    }
]

const Tuesday = [
    {   
        time: '09-10 AM',
        activity: 'Video Lesson',
        topic: 'Recursion Basics',
        status: 'Completed'
    },
    {   
        time: '11-12 AM',
        activity: 'Hands-on Practice',
        topic: 'Fibonacci Series',
        status: 'In Progress'
    },
    {   
        time: '12-01 PM',
        activity: 'Coding Challenge',
        topic: 'Merge Sort',
        status: 'Not Started'
    },
    {   
        time: '02-03 PM',
        activity: 'Group Discussion',
        topic: 'Algorithm Efficiency',
        status: 'Upcoming'
    }
]

const Wednesday = [
    {   
        time: '10-11 AM',
        activity: 'Coding Challenge',
        topic: 'Graph Traversal (BFS/DFS)',
        status: 'Completed'
    },
    {   
        time: '11-12 AM',
        activity: 'Interactive Quiz',
        topic: 'Data Structures (Stacks & Queues)',
        status: 'In Progress'
    }
]

const Thursday = [
    {   
        time: '11-12 AM',
        activity: 'Video Lesson',
        topic: 'Linked Lists',
        status: 'Completed'
    },
    {   
        time: '01-02 PM',
        activity: 'Hands-on Practice',
        topic: 'Dijkstra’s Algorithm',
        status: 'In Progress'
    },
    {   
        time: '02-03 PM',
        activity: 'Coding Challenge',
        topic: 'Recursion Problems',
        status: 'Not Started'
    }
]

const Friday = [
    {   
        time: '10-11 AM',
        activity: 'Quiz',
        topic: 'Sorting & Searching',
        status: 'Completed'
    },
    {   
        time: '11-12 AM',
        activity: 'Interactive Lesson',
        topic: 'Heaps & Priority Queues',
        status: 'In Progress'
    },
    {   
        time: '02-03 PM',
        activity: 'Project Work',
        topic: 'Build a Pathfinding Algorithm',
        status: 'Upcoming'
    }
]

const Saturday = [
    {   
        time: '09-10 AM',
        activity: 'Video Lesson',
        topic: 'Dynamic Programming Basics',
        status: 'Completed'
    },
    {   
        time: '10-11 AM',
        activity: 'Coding Challenge',
        topic: 'Knapsack Problem',
        status: 'In Progress'
    },
    {   
        time: '01-02 PM',
        activity: 'Project Review',
        topic: 'Algorithm Implementation Feedback',
        status: 'Upcoming'
    }
]
